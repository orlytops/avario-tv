#
#
# Avario
# HASS - API Extentions for Home Assitant by Avario
#
# Binary Bean Technologies Inc.
# Chris J. Veeneman / cj.veeneman@gmail.com
# Dec 2016
#
#

import os
import logging
import yaml
import json
from aiohttp import web, hdrs
from pprint import pprint

DOMAIN = 'avario'
ATTR_NAME = 'stateArray'
DEFAULT_STATE = '{}'
ROOMS_KEY = "group.rooms"
SCENES_KEY = "scene"
HA_CONFIG = '/home/hass/.homeassistant/'
SCRIPTS = 'script.yaml'

_LOGGER = logging.getLogger(__name__)

import json
#from aiohttp import web
from homeassistant.core import callback
from homeassistant.components.http import HomeAssistantView

_REGISTERED_COMPONENTS = set()

#
# entry point
#
def setup(hass, config):

	def setStateArray(call):

		name = call.data.get( ATTR_NAME, DEFAULT_STATE )
		hass.states.set( 'avario.stateArray', name )

	#hass.services.register( DOMAIN, 'setStateArray', setStateArray )
	hass.http.register_view( wv_getExcelConfigCSV )
	hass.http.register_view( wv_getAll )

	_LOGGER.info( "AVARIO: service / AvarioStateArrayWebView setup()" );
	return True

#
# web view - 
# api entry for AvarioArrays.getExcelConfigCSV()
#
class wv_getExcelConfigCSV(HomeAssistantView):
	"""View to bootstrap frontend with all needed data."""

	url = "/api/avarioexcelconfig"
	name = "api:avarioexcelconfig"
	
	@callback
	def get(self, request):
		"""
			Return the avario state array
			as json 
		"""
		#avarioArrays = AvarioArrays( self.hass );
		print( "HERE" )
		return web.Response( body="YAY!", content_type="text/plain", status=200 )
		#return( self.json( avarioArrays.getExcelConfig() ) )

#
# web view - 
# api entry for AvarioArrays.getAll()
#
class wv_getAll(HomeAssistantView):
	"""View to bootstrap frontend with all needed data."""

	url = "/api/avariostatearray"
	name = "api:avariostatearray"

	@callback
	def get(self, request):
		"""
			Return the avario state array
			as json 
		"""
		#print( request.query_string )

		avarioArrays = AvarioArrays( self.hass );
		return( self.json( avarioArrays.getAll() ) )
#
# 
#
class AvarioArrays(object):

	def __init__( self, hass ):
		""" 
			initialize our object, automatically getting the internal hass states 
			and converting them to a dict of dict's
		"""
		_LOGGER.info( "AVARIO: AvarioArrays __init__" );

		self.hass = hass;
		self.avarioStateArray = {}
		self.avarioStateArray[ 'states' ] = []
		for hs in self.hass.states.async_all():
			self.avarioStateArray[ 'states' ].append( hs.as_dict() );

	def getAll( self ):
		"""
			get the "avario version" of the hass state array
		"""
		_LOGGER.info( "AVARIO: AvarioArrays getAll()" );

		self.avarioStateArray[ 'rooms' ] = self.getRooms();
		self.avarioStateArray[ 'scenes' ] = self.getScenes();
		self.avarioStateArray[ 'scripts' ] = self.getScripts();
		#...
		return( self.avarioStateArray )

	def getRooms( self ):
		"""
			traverse the states looking for the specific "groups.rooms" group
			gather the rooms within it's attributes.entity_id array
			then using those entity_id's as an index into a new room array, include their friendly names
		"""
		_LOGGER.info( "AVARIO: AvarioArrays getRooms()" );
		subArray = [];
		for state in self.avarioStateArray[ 'states' ]:
			if ROOMS_KEY == state[ 'entity_id' ][:len(ROOMS_KEY)].lower():
				for room in state[ 'attributes' ][ 'entity_id' ]:
					subArray.append( { room : self.getAttributesFromEntity( room ) } );
				return( subArray )
		subArray.append( { 'error' : 'ROOMS_KEY=\''+ROOMS_KEY+'\', not found.  Ensure your configuation groups includes a \''+ROOMS_KEY+'\' section.'} )
		return( subArray )

	def getScenes( self ):
		"""
			traverse the states looking for scenes type entities
			creating an array (indexed by scene entity_id)
			of the scene's attributes
		"""
		_LOGGER.info( "AVARIO: AvarioArrays getScenes()" );
		subArray = [];
		for state in self.avarioStateArray[ 'states' ]:
			if SCENES_KEY == state[ 'entity_id' ][:len(SCENES_KEY)].lower():
				subArray.append( { state[ 'entity_id' ] : state[ 'attributes' ] } );
		return( subArray )

	def getScripts( self ):
		"""
			parse the scripts.yaml and create a sub array of scripts (indexed by entity_id)
			that contains scriptEntity (the avario variable that lists any entity that we want to show associated with this script
		"""
		_LOGGER.info( "AVARIO: AvarioArrays getScripts()" );
		global HA_CONFIG, SCRIPTS;

		subArray = [];
		with open( ( HA_CONFIG + SCRIPTS ), 'r' ) as yamlStream:
			scripts = yaml.load( yamlStream )
			for script in scripts:
				if 'scriptentity' in scripts[ script ]:
					subArray.append( { script : scripts[ script ][ 'scriptentity' ] } )
		return( subArray )

	def getAttributesFromEntity( self, entity_id ):
		"""
		return the state dict from the state array that matches entity_id
		"""
		for state in self.avarioStateArray[ 'states' ]:
			if state[ 'entity_id' ].lower() == entity_id.lower():
				return( state[ 'attributes' ] )
		return( None )

	def getExcelConfig( self ):
		"""
			return a list of csv data used by Richard's excel gui
		"""
		_LOGGER.info( "AVARIO: AvarioArrays getExcelConfig()" );
		subArray = [];
		#for state in self.avarioStateArray[ 'states' ]:

		return( subArray )

"""
	def getScenes( self ):

		global SCENES
		scenesArray = {}

		for yamlFile in glob.glob( SCENES ):
			with open( yamlFile, 'r' ) as yamlStream:
				scene = yaml.load( yamlStream )

				print( "scene: " + scene['name'] )
				scenesArray[scene['name']] = [];

				for entity in scene['entities']:
					print( "adding: " + entity )
					scenesArray[scene['name']].append( entity )
					print( "this scene entity list now: " + str( scenesArray[scene['name']] ) )

		return( scenesArray )
"""
